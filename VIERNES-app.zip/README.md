# VIERNES · asistente de IA personal
1. Crea un repo en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. Settings > Pages > Source: **GitHub Actions**. Tu app quedará en `https://TU-USUARIO.github.io/TU-REPO/`.
3. Ábrela en Chrome del celular > menú ⋮ > **Instalar app**. Funciona con voz.
4. Ajustes dentro de la app: pega tu clave gratis de https://aistudio.google.com/apikey
## APK
- Fácil y con voz: https://www.pwabuilder.com con la URL de tu página > Android.
- Con GitHub: pestaña Actions > **Crear APK** > Run workflow > descarga `VIERNES-apk`. (El micrófono en este APK no funciona; usa PWABuilder para voz.)
